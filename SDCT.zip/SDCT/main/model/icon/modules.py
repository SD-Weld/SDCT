#!/usr/bin/python3
#coding=utf-8

import numpy as np
import matplotlib.pyplot as plt
import torch
import torch.nn as nn
import torch.nn.functional as F
import math
import copy
import os
import numbers
eps = 1e-12







def cus_sample(feat, **kwargs):
    """
    :param feat: 输入特征
    :param kwargs: size或者scale_factor
    """
    assert len(kwargs.keys()) == 1 and list(kwargs.keys())[0] in ["size", "scale_factor"]
    return F.interpolate(feat, **kwargs, mode="bilinear", align_corners=False)

def weight_init(module):
    for n, m in module.named_children():
        if isinstance(m, nn.Conv2d):
            nn.init.kaiming_normal_(m.weight, mode='fan_in', nonlinearity='relu')
            if m.bias is not None:
                nn.init.zeros_(m.bias)
        elif isinstance(m, (nn.BatchNorm2d, nn.InstanceNorm2d, nn.LayerNorm)):
            nn.init.ones_(m.weight)
            if m.bias is not None:
                nn.init.zeros_(m.bias)
        elif isinstance(m, nn.Linear): 
            nn.init.kaiming_normal_(m.weight, mode='fan_in', nonlinearity='relu')
            if m.bias is not None:
                nn.init.zeros_(m.bias)
        elif isinstance(m, nn.Sequential):
            weight_init(m)
        elif isinstance(m, (nn.AvgPool2d,nn.MaxPool2d,nn.ReLU, nn.Sigmoid, nn.Softmax, nn.PReLU, nn.AdaptiveAvgPool2d, nn.AdaptiveMaxPool2d, nn.AdaptiveAvgPool1d, nn.Sigmoid, nn.Identity)):
            pass
        else:
            m.initialize()


class CropLayer(nn.Module):
    #   E.g., (-1, 0) means this layer should crop the first and last rows of the feature map. And (0, -1) crops the first and last columns
    def __init__(self, crop_set):
        super(CropLayer, self).__init__()
        self.rows_to_crop = - crop_set[0]
        self.cols_to_crop = - crop_set[1]
        assert self.rows_to_crop >= 0
        assert self.cols_to_crop >= 0

    def forward(self, input):
        return input[:, :, self.rows_to_crop:-self.rows_to_crop, self.cols_to_crop:-self.cols_to_crop]


class asyConv(nn.Module):

    def __init__(self, in_channels, out_channels, kernel_size, stride=1, padding=0, dilation=1, groups=1, padding_mode='zeros', deploy=False):
        super(asyConv, self).__init__()
        self.deploy = deploy
        if deploy:
            self.fused_conv = nn.Conv2d(in_channels=in_channels, out_channels=out_channels, kernel_size=(kernel_size,kernel_size), stride=stride,
                                      padding=padding, dilation=dilation, groups=groups, bias=True, padding_mode=padding_mode)
            self.initialize()
        else:
            self.square_conv = nn.Conv2d(in_channels=in_channels, out_channels=out_channels,
                                         kernel_size=(kernel_size, kernel_size), stride=stride,
                                         padding=padding, dilation=dilation, groups=groups, bias=False,
                                         padding_mode=padding_mode)
            self.square_bn = nn.BatchNorm2d(num_features=out_channels)

            center_offset_from_origin_border = padding - kernel_size // 2
            ver_pad_or_crop = (center_offset_from_origin_border + 1, center_offset_from_origin_border)
            hor_pad_or_crop = (center_offset_from_origin_border, center_offset_from_origin_border + 1)
            if center_offset_from_origin_border >= 0:
                self.ver_conv_crop_layer = nn.Identity()
                # 占位，啥也不干
                ver_conv_padding = ver_pad_or_crop
                self.hor_conv_crop_layer = nn.Identity()
                hor_conv_padding = hor_pad_or_crop
            else:
                self.ver_conv_crop_layer = CropLayer(crop_set=ver_pad_or_crop)
                ver_conv_padding = (0, 0)
                self.hor_conv_crop_layer = CropLayer(crop_set=hor_pad_or_crop)
                hor_conv_padding = (0, 0)
            self.ver_conv = nn.Conv2d(in_channels=in_channels, out_channels=out_channels, kernel_size=(3, 1),
                                      stride=stride,
                                      padding=ver_conv_padding, dilation=dilation, groups=groups, bias=False,
                                      padding_mode=padding_mode)

            self.hor_conv = nn.Conv2d(in_channels=in_channels, out_channels=out_channels, kernel_size=(1, 3),
                                      stride=stride,
                                      padding=hor_conv_padding, dilation=dilation, groups=groups, bias=False,
                                      padding_mode=padding_mode)
            self.ver_bn = nn.BatchNorm2d(num_features=out_channels)
            self.hor_bn = nn.BatchNorm2d(num_features=out_channels)
            self.initialize()


    def forward(self, input):
        if self.deploy:
            return self.fused_conv(input)
        else:
            square_outputs = self.square_conv(input)
            square_outputs = self.square_bn(square_outputs)
            vertical_outputs = self.ver_conv_crop_layer(input)
            vertical_outputs = self.ver_conv(vertical_outputs)
            vertical_outputs = self.ver_bn(vertical_outputs)
            horizontal_outputs = self.hor_conv_crop_layer(input)
            horizontal_outputs = self.hor_conv(horizontal_outputs)
            horizontal_outputs = self.hor_bn(horizontal_outputs)
            return square_outputs + vertical_outputs + horizontal_outputs

    def initialize(self):
        weight_init(self)

class BasicConv2d(nn.Module):
    def __init__(self, in_planes, out_planes, kernel_size, stride=1, padding=0, dilation=1):
        super(BasicConv2d, self).__init__()
        self.conv = nn.Conv2d(in_planes, out_planes,
                              kernel_size=kernel_size, stride=stride,
                              padding=padding, dilation=dilation, bias=False)
        self.bn = nn.BatchNorm2d(out_planes)
        self.relu = nn.ReLU(inplace=True)

        self.initialize()
    def forward(self, x):
        x = self.conv(x)
        x = self.bn(x)
        x = self.relu(x)
        return x
    def initialize(self):
        weight_init(self)
class CRBC(nn.Module):
    """ Enhance the feature diversity.
    """
    def __init__(self, x, y):
        super(CRBC, self).__init__()
        self.oriConv = nn.Conv2d(x, y, kernel_size=3, stride=1, padding=1)
        self.conv2d = nn.Conv2d(y, y, kernel_size=3, stride=1, padding=1)
        self.bn2d = nn.BatchNorm2d(y)
        self.initialize()

    def forward(self, f):
        p1 = self.oriConv(f)
        p  = F.relu(self.bn2d(self.conv2d(p1)), inplace=True)

        return p

    def initialize(self):
        #pass
        weight_init(self)
class SpatialAttention(nn.Module):  #SA
    def __init__(self, kernel_size=7):
        super(SpatialAttention, self).__init__()

        assert kernel_size in (3, 7), 'kernel size must be 3 or 7'
        padding = 3 if kernel_size == 7 else 1

        self.conv1 = nn.Conv2d(1, 1, kernel_size, padding=padding, bias=False)
        self.sigmoid = nn.Sigmoid()

        self.initialize()
    def forward(self, x):
        max_out, _ = torch.max(x, dim=1, keepdim=True)
        x = max_out
        x = self.conv1(x)
        return self.sigmoid(x)
    def initialize(self):
        weight_init(self)
class CSWeight(nn.Module):
    def __init__(self, left_channel, right_channel):
        super(CSWeight, self).__init__()
        self.upsample = cus_sample
        self.conv1 = BasicConv2d(left_channel, right_channel, kernel_size=3, stride=1, padding=1)
        self.sa1 = SpatialAttention()
        self.sa2 = SpatialAttention()
        self.conv_cat = BasicConv2d(2*right_channel, right_channel, 3, padding=1)
        self.conv2 = nn.Conv2d(right_channel, right_channel, kernel_size=3, stride=1, padding=1)
        self.sigmoid = nn.Sigmoid()
        self.fusion = BasicConv2d(right_channel, right_channel, 3, padding=1)

        self.initialize()
    def forward(self, left, right):
        left = self.upsample(left, scale_factor=2)  # right 上采样
        left = self.conv1(left)
        x1 = left.mul(self.sa2(right))+left
        x2 = right.mul(self.sa1(left))+right
        mid = self.conv_cat(torch.cat((x1, x2), 1)) #concat
        mid = self.conv2(mid)
        wei = self.sigmoid(mid)
        out = self.fusion(left * wei + right * (1 - wei))  # wei*left + (1-wei)*right
        return out
    def initialize(self):
        weight_init(self)
class CSFI(nn.Module):
    def __init__(self, h_C, l_C):
        super(CSFI, self).__init__()
        self.h2l_pool = nn.AvgPool2d((2, 2), stride=2)
        # self.h2h_pool = nn.AvgPool2d((2, 2), stride=2)
        self.l2h_up = cus_sample
        self.h2l_0 = nn.Conv2d(h_C, l_C, 3, 1, 1)
        self.l2l_0 = nn.Conv2d(h_C, h_C, 3, 1, 1)
        self.l2l_1 = nn.Conv2d(l_C, l_C, 3, 1, 1)
        self.h1h_1 = nn.Conv2d(h_C, h_C, 3, 1, 1)
        self.h2h_0 = nn.Conv2d(h_C, h_C, 3, 1, 1)
        self.bnl_0 = nn.BatchNorm2d(l_C)
        self.bnh_0 = nn.BatchNorm2d(h_C)

        self.contrast1 = Contrast(h_C) #Contrast模块
        self.contrast2 = Contrast(l_C)  # Contrast模块
        # self.contrast3 = Contrast(h_C) #Contrast模块
        # self.contrast4 = Contrast(h_C)  # Contrast模块

        self.h2h_1 = nn.Conv2d(h_C, h_C, 3, 1, 1)
        self.h2l_1 = nn.Conv2d(h_C, h_C, 3, 1, 1)
        # self.h2h_2 = nn.Conv2d(h_C, h_C, 3, 1, 1)
        self.l2h_1 = nn.Conv2d(l_C, h_C, 3, 1, 1)
        self.l2l_2 = nn.Conv2d(l_C, l_C, 3, 1, 1)

        self.conv1= nn.Conv2d(l_C, h_C, 3, 1, 1)

        self.bnl_1 = nn.BatchNorm2d(h_C)
        self.bnh_1 = nn.BatchNorm2d(h_C)

        # self.csweight = CSWeight(l_C, h_C)
        self.relu = nn.ReLU(True)
        self.conv_out = nn.Conv2d(2*h_C, h_C, 3, 1, 1)

        self.initialize()
    def forward(self, x):
        h, w = x.shape[2:]

        # 第一层
        x_h = self.relu(self.bnh_0(self.h2h_0(x)))
        x_l = self.relu(self.bnl_0(self.h2l_0(self.h2l_pool(x))))
        # print(x_h.shape)
        # print(x_l.shape)
        # torch.Size([8, 64, 40, 40])
        # torch.Size([8, 32, 20, 20])
        # 中间层
        x_h2h = self.contrast1(x_h)# 经过contrast层
        # print(x_h2h.shape)
        x_h2h = self.h2h_1(x_h2h)
        x_l2l = self.contrast2(x_l)# 经过contrast层
        x_l2l = self.l2l_1(x_l2l)

        # x_l2h = self.l2h_1(self.l2h_up(x_l2l, size=(h, w)))
        x_l2h = self.l2h_1(self.l2h_up(x_l2l, size=(h, w)))
        x_h = self.relu(self.bnh_1(self.h1h_1(x_h2h + x_l2h)))
        # x_h = self.contrast4(x_h)# 经过contrast层

        # x_h2l = self.h2h_pool(x_h2h)
        # x_h2l = self.h2l_1(self.l2h_up(x_h2h, size=(h, w)))

        x_h2l = self.h2l_1(x_h2h)
        # print(x_h2l.shape)
        # print(x_l2l.shape)
        x_l2l=self.conv1(self.l2h_up(x_l2l, size=(h, w)))
        x_l = self.relu(self.bnl_1(self.l2l_0(x_l2l+x_h2l)))

        out = self.conv_out(torch.cat((x_h, x_l), 1))
        return out
    def initialize(self):
        weight_init(self)
class CSAF(nn.Module):
    def __init__(self, left_channel, right_channel):
        super(CSAF, self).__init__()
        self.avg_pool = nn.AvgPool2d((2, 2), stride=2)
        self.max_pool = nn.MaxPool2d((2, 2), stride=2)
        self.up = cus_sample
        self.conv_pool = nn.Conv2d(left_channel, right_channel, 3, 1, 1)
        self.conv_max = nn.Conv2d(left_channel, right_channel, 3, 1, 1)

        self.conv = nn.Conv2d(left_channel, left_channel, 3, 1, 1)
        self.bn = nn.BatchNorm2d(left_channel)
        self.bn_pool = nn.BatchNorm2d(right_channel)
        self.bn_max = nn.BatchNorm2d(right_channel)

        self.contrast1 = Contrast(right_channel) #Contrast模块
        self.contrast2 = Contrast(right_channel)  # Contrast模块

        self.conv_max2 = nn.Conv2d(right_channel, right_channel, 3, 1, 1)
        self.conv_max3 = nn.Conv2d(right_channel, left_channel, 3, 1, 1)
        self.conv_pool2 = nn.Conv2d(right_channel, right_channel, 3, 1, 1)
        self.conv_pool3 = nn.Conv2d(right_channel, left_channel, 3, 1, 1)

        self.relu = nn.ReLU(True)
        self.conv_out1 = nn.Conv2d(2*left_channel, left_channel, 3, 1, 1)
        self.conv_out2 = nn.Conv2d(left_channel, left_channel, 3, 1, 1)
        self.initialize()
    def forward(self, x):
        h, w = x.shape[2:]

        # 第一层
        x_h = self.relu(self.bn(self.conv(x)))

        x_pool = self.relu(self.bn_pool(self.conv_pool(self.avg_pool(x_h))))
        x_pool = self.contrast2(x_pool)# 经过contrast层
        x_pool = self.conv_pool2(x_pool)
        x_pool = self.conv_pool3(self.up(x_pool, size=(h, w)))

        x_max = self.relu(self.bn_max(self.conv_max(self.max_pool(x_h))))
        x_max = self.contrast1(x_max)# 经过contrast层
        x_max= self.conv_max2(x_max)
        x_max = self.conv_max3(self.up(x_max, size=(h, w)))

        out = self.conv_out2(x_h+self.conv_out1(torch.cat((x_pool, x_max), 1)))
        return out
    def initialize(self):
        weight_init(self)
class Contrast(nn.Module):
    def __init__(self, in_c):
        super(Contrast, self).__init__()
        self.avg_pool = nn.AvgPool2d((3, 3), stride=1,padding=1)
        self.conv_1 = nn.Conv2d(in_c, in_c, kernel_size=1, stride=1, padding=0)
        self.bn1 = nn.BatchNorm2d(in_c)
        self.sigmoid = nn.Sigmoid()

        self.initialize()
    def forward(self, x):
        edge = x-self.avg_pool(x)  #Xi=X-Avgpool(X)
        weight = self.sigmoid(self.bn1(self.conv_1(edge)))
        out = weight*x + x

        return out#Res
    def initialize(self):
        weight_init(self)


class FeaProp_1(nn.Module):
    def __init__(self, in_planes):
        self.init__ = super(FeaProp_1, self).__init__()

        act_fn = nn.ReLU(inplace=True)

        self.layer_1 = nn.Sequential(nn.Conv2d(in_planes, in_planes, kernel_size=3, stride=1, padding=1),
                                     nn.BatchNorm2d(in_planes), act_fn)
        self.layer_2 = nn.Sequential(nn.Conv2d(in_planes, in_planes, kernel_size=3, stride=1, padding=1),
                                     nn.BatchNorm2d(in_planes), act_fn)

        self.gate_1 = nn.Conv2d(in_planes * 2, 1, kernel_size=1, bias=True)
        self.gate_2 = nn.Conv2d(in_planes * 2, 1, kernel_size=1, bias=True)
        self.softmax = nn.Softmax(dim=1)

        self.sa1 = SpatialAttention()
        self.sa2 = SpatialAttention()
        self.conv_cat = BasicConv2d(2 * in_planes, in_planes, 3, padding=1)
        self.conv2 = nn.Conv2d(in_planes, in_planes, kernel_size=3, stride=1, padding=1)
        self.sigmoid = nn.Sigmoid()
        self.fusion = BasicConv2d(in_planes, in_planes, 3, padding=1)

        self.initialize()
    def forward(self, x10, x20):
        ###
        x1 = self.layer_1(x10)
        x2 = self.layer_2(x20)

        cat_fea = torch.cat([x1, x2], dim=1)

        ###
        att_vec_1 = self.gate_1(cat_fea)
        att_vec_2 = self.gate_2(cat_fea)

        att_vec_cat = torch.cat([att_vec_1, att_vec_2], dim=1)
        att_vec_soft = self.softmax(att_vec_cat)

        att_soft_1, att_soft_2 = att_vec_soft[:, 0:1, :, :], att_vec_soft[:, 1:2, :, :]
        left = x1+x1 * att_soft_1
        right = x2+x2 * att_soft_2
        x_1 = left.mul(self.sa2(right))+left
        x_2 = right.mul(self.sa1(left))+right
        mid = self.conv2(self.conv_cat(torch.cat((x_1, x_2), 1)))#concat
        mid = self.sigmoid(mid)
        out = left * mid + right * mid
        out = self.fusion(out)

        return out
    def initialize(self):
        weight_init(self)
class FeaProp(nn.Module):
    def __init__(self, in_planes):
        self.init__ = super(FeaProp, self).__init__()
        self.sa1 = SpatialAttention()
        self.sa2 = SpatialAttention()
        self.conv_cat = BasicConv2d(2 * in_planes, in_planes, 3, padding=1)
        self.conv2 = nn.Conv2d(in_planes, in_planes, kernel_size=3, stride=1, padding=1)
        self.sigmoid = nn.Sigmoid()
        self.fusion = BasicConv2d(in_planes, in_planes, 3, padding=1)
        # self.asyConv = asyConv(in_channels=in_planes, out_channels=in_planes, kernel_size=3, stride=1, padding=1, dilation=1, groups=1,
        #                        padding_mode='zeros', deploy=False)
        # self.atrConv = nn.Sequential(
        #     nn.Conv2d(in_planes, in_planes, kernel_size=3, dilation=2, padding=2, stride=1), nn.BatchNorm2d(in_planes), nn.PReLU()
        # )
        # self.atrConv = nn.Conv2d(in_planes, in_planes, kernel_size=3, dilation=2, padding=2, stride=1)

        self.fusion2 = BasicConv2d(in_planes, in_planes, 3, padding=1)
        self.initialize()
    def forward(self, left, right):
        ###
        x_1 = left.mul(self.sa2(right))+left
        x_2 = right.mul(self.sa1(left))+right
        mid = self.conv2(self.conv_cat(torch.cat((x_1, x_2), 1)))#concat
        mid = self.sigmoid(mid)
        # mid = self.conv_cat(torch.cat((x_1, x_2), 1))  # concat
        # mid1=self.conv2(mid)
        # mid2=self.atrConv(mid)
        # mid3=self.asyConv(mid)
        # mid = self.sigmoid(mid1+mid2+mid3)
        out = left * mid + right * (1-mid)
        out = self.fusion(out)
        out = self.fusion2(x_1+out*x_1)
        return out
    def initialize(self):
        weight_init(self)
class decoder(nn.Module):
    def __init__(self, channels):
        super(decoder, self).__init__()
        self.conv_trans1 = nn.Conv2d(channels*3, 64, kernel_size=3, stride=1, padding=1, bias=False)
        self.conv_trans2 = nn.Conv2d(64, 64, kernel_size=3, stride=1, padding=1, bias=False)
        # self.conv_trans3 = nn.Conv2d(64, 1, kernel_size=3, stride=1, padding=1, bias=False)
        self.bn_trans = nn.BatchNorm2d(64)
        self.csfim1 = CSAF(64,32)
        self.csfim2 = CSAF(64, 32)
        self.csfim3 = CSAF(64, 32)
        # self.csfim4 = CSFI(64, 32)
        self.conv1 = nn.Conv2d(128, 64, kernel_size=3, stride=1, padding=1, bias=False)
        self.bn1 = nn.BatchNorm2d(64)

        self.conv2 = nn.Conv2d(128, 64, kernel_size=3, stride=1, padding=1, bias=False)
        self.bn2 = nn.BatchNorm2d(64)

        self.conv3 = nn.Conv2d(128, 64, kernel_size=3, stride=1, padding=1, bias=False)
        self.bn3 = nn.BatchNorm2d(64)

        self.conv4 = nn.Conv2d(64, 64, kernel_size=3, stride=1, padding=1, bias=False)

        self.fuse1  = nn.Sequential(nn.Conv2d(64, 64, kernel_size=1), nn.Conv2d(64, 64, kernel_size=3, padding=1), nn.BatchNorm2d(64), nn.ReLU(inplace=True))
        self.fuse2  = nn.Sequential(nn.Conv2d(64, 64, kernel_size=1), nn.Conv2d(64, 64, kernel_size=3, padding=1), nn.BatchNorm2d(64), nn.ReLU(inplace=True))
        self.fuse3  = nn.Sequential(nn.Conv2d(64, 64, kernel_size=1), nn.Conv2d(64, 64, kernel_size=3, padding=1), nn.BatchNorm2d(64), nn.ReLU(inplace=True))
        self.fuse4  = nn.Sequential(nn.Conv2d(64, 64, kernel_size=1), nn.Conv2d(64, 64, kernel_size=3, padding=1), nn.BatchNorm2d(64), nn.ReLU(inplace=True))

        self.fea_pro1 = FeaProp(64)
        self.fea_pro2 = FeaProp(64)
        self.fea_pro3 = FeaProp(64)
        self.fea_pro4 = FeaProp(64)
        # self.MSA=MSA_module(dim = channels)
        self.drf = DRF(channels)

        self.initialize()

    def forward(self,input1, input2, input3,input4):
        # print(input4.shape)
        # torch.Size([8, 64, 176, 176])


        if input1.size()[2:] != input2.size()[2:]:
            input1 = F.interpolate(input1, size=input2.size()[2:], mode='bilinear')
        if input3.size()[2:] != input2.size()[2:]:
            input3 = F.interpolate(input3, size=input2.size()[2:], mode='bilinear')

        input_fuse = torch.cat((input1, input2, input3), 1)

        # conv
        input_fuse = self.conv_trans1(input_fuse)
        out_fuse = F.relu(self.bn_trans(self.conv_trans2(input_fuse)), inplace=True)

        out_fuse=self.drf(out_fuse)
        # 新添加  前景背景全局注意
        # out = self.conv_trans3(out_fuse)
        # out_fuse=self.MSA(out_fuse,out)
        # input_fuse =self.csfim(input_fuse)
        # print(input_fuse.shape)
        # torch.Size([8, 64, 36, 36])

        pose1 = F.interpolate(out_fuse, size=input1.size()[2:], mode='bilinear')
        pose2 = F.interpolate(out_fuse, size=input2.size()[2:], mode='bilinear')
        pose3 = F.interpolate(out_fuse, size=input3.size()[2:], mode='bilinear')

        input1 = torch.cat((input1, pose1),1)
        input2 = torch.cat((input2, pose2),1)
        input3 = torch.cat((input3, pose3),1)

        out1 = F.relu(self.bn1(self.csfim1(self.conv1(input1))), inplace=True)
        out2 = F.relu(self.bn2(self.csfim2(self.conv2(input2))), inplace=True)
        out3 = F.relu(self.bn3(self.csfim3(self.conv3(input3))), inplace=True)

        out1 = F.interpolate(out1,   size=out2.size()[2:], mode='bilinear')
        #
        out2 = self.fea_pro1(out2,out1)
        # out2 = self.fuse2(out2 * out1) + out2
        out2 = F.interpolate(out2,   size=out3.size()[2:], mode='bilinear')
        out3 = self.fea_pro2(out3,out2)
        # out3 = self.fuse3(out3 * out2) + out3

        out3 = F.interpolate(out3,   size=input4.size()[2:], mode='bilinear')
        # out4=self.csfim4(self.conv4(input4))
        out4 = self.fea_pro3(input4, out3)
        # out4 = self.fuse4(input4 * out3) + input4

        return out1, out2, out3, out4, out_fuse
    def initialize(self):
        weight_init(self)


class MRF(nn.Module):
    def __init__(self, in_channels, out_channels,rate=[1,2,4,8]):
        super(MRF, self).__init__()

        inner_channels=in_channels//4

        self.gap = nn.AdaptiveAvgPool2d(1)

        self.conv1= nn.Sequential(
            nn.Conv2d(in_channels, inner_channels, 1),
            nn.BatchNorm2d(inner_channels),
            nn.ReLU(inplace=True),
            nn.Conv2d(inner_channels, inner_channels, 3, dilation=rate[0], padding=rate[0]),
            nn.BatchNorm2d(inner_channels),
            nn.ReLU(inplace=True),
        )

        self.conv2 = nn.Sequential(
            nn.Conv2d(in_channels, inner_channels, 1),
            nn.BatchNorm2d(inner_channels),
            nn.ReLU(inplace=True),
            nn.Conv2d(inner_channels, inner_channels, 3, dilation=rate[1], padding=rate[1]),
            nn.BatchNorm2d(inner_channels),
            nn.ReLU(inplace=True),
        )

        self.conv3 = nn.Sequential(
            nn.Conv2d(in_channels, inner_channels, 1),
            nn.BatchNorm2d(inner_channels),
            nn.ReLU(inplace=True),
            nn.Conv2d(inner_channels, inner_channels, 3, dilation=rate[2], padding=rate[2]),
            nn.BatchNorm2d(inner_channels),
            nn.ReLU(inplace=True),
            )

        self.pro = nn.Sequential(
            nn.Conv2d(inner_channels * 3, out_channels, 1),
            nn.BatchNorm2d(out_channels),
            nn.ReLU()
        )

    def forward(self, x):

        feat1 = self.conv1(x)
        feat2 = self.conv2(x)
        feat3 = self.conv3(x)
        out = torch.cat([feat1, feat2, feat3], dim=1)

        return self.pro(out)
    def initialize(self):
        weight_init(self)
class DRF(nn.Module):
    def __init__(self, in_channels):
        super(DRF, self).__init__()
        out_channels =64
        self.mrf1 = MRF(in_channels,out_channels)
        self.mrf2 = MRF(in_channels,out_channels)
        self.mrf3 = MRF(in_channels,out_channels)
        self.gap=nn.AdaptiveAvgPool2d(1)
        self.conv4 = nn.Sequential(
            nn.Conv2d(in_channels, in_channels, 1),
            nn.BatchNorm2d(in_channels),
            nn.ReLU(inplace=True),
        )
        self.relu= nn.ReLU(inplace=True)
        self.pro = nn.Sequential(
            nn.Conv2d(in_channels , out_channels, 3, padding=1),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True),
        )


    def forward(self, x):

        size = x.size()[2:]
        feat1 = self.mrf1(x)
        input = x + feat1
        feat2 = self.mrf2(input)
        input = x+feat1+feat2
        feat3 = self.mrf3(input)
        feat4 = F.interpolate(self.conv4(self.gap(x)), size, mode='bilinear', align_corners=True)
        feat = x+feat1+feat2+feat3+feat4
        out = self.pro(feat)
        return out
    def initialize(self):
        weight_init(self)
from einops import rearrange
def to_3d(x):
    return rearrange(x, 'b c h w -> b (h w) c')


def to_4d(x, h, w):
    return rearrange(x, 'b (h w) c -> b c h w', h=h, w=w)


class BiasFree_LayerNorm(nn.Module):
    def __init__(self, normalized_shape):
        super(BiasFree_LayerNorm, self).__init__()
        if isinstance(normalized_shape, numbers.Integral):
            normalized_shape = (normalized_shape,)
        normalized_shape = torch.Size(normalized_shape)

        assert len(normalized_shape) == 1

        self.weight = nn.Parameter(torch.ones(normalized_shape))
        self.normalized_shape = normalized_shape

    def forward(self, x):
        sigma = x.var(-1, keepdim=True, unbiased=False)
        return x / torch.sqrt(sigma + 1e-5) * self.weight


class WithBias_LayerNorm(nn.Module):
    def __init__(self, normalized_shape):
        super(WithBias_LayerNorm, self).__init__()
        if isinstance(normalized_shape, numbers.Integral):
            normalized_shape = (normalized_shape,)
        normalized_shape = torch.Size(normalized_shape)

        assert len(normalized_shape) == 1

        self.weight = nn.Parameter(torch.ones(normalized_shape))
        self.bias = nn.Parameter(torch.zeros(normalized_shape))
        self.normalized_shape = normalized_shape

    def forward(self, x):
        mu = x.mean(-1, keepdim=True)
        sigma = x.var(-1, keepdim=True, unbiased=False)
        return (x - mu) / torch.sqrt(sigma + 1e-5) * self.weight + self.bias

    def initialize(self):
        weight_init(self)


class LayerNorm(nn.Module):
    def __init__(self, dim, LayerNorm_type):
        super(LayerNorm, self).__init__()
        if LayerNorm_type == 'BiasFree':
            self.body = BiasFree_LayerNorm(dim)
        else:
            self.body = WithBias_LayerNorm(dim)

    def forward(self, x):
        h, w = x.shape[-2:]
        return to_4d(self.body(to_3d(x)), h, w)

    def initialize(self):
        weight_init(self)


class FeedForward(nn.Module):
    def __init__(self, dim, ffn_expansion_factor, bias):
        super(FeedForward, self).__init__()
        hidden_features = int(dim * ffn_expansion_factor)
        self.project_in = nn.Conv2d(dim, hidden_features * 2, kernel_size=1, bias=bias)
        self.dwconv = nn.Conv2d(hidden_features * 2, hidden_features * 2, kernel_size=3, stride=1, padding=1,
                                groups=hidden_features * 2, bias=bias)
        self.project_out = nn.Conv2d(hidden_features, dim, kernel_size=1, bias=bias)

    def forward(self, x):
        x = self.project_in(x)
        x1, x2 = self.dwconv(x).chunk(2, dim=1)
        x = F.gelu(x1) * x2
        x = self.project_out(x)
        return x

    def initialize(self):
        weight_init(self)


class Attention(nn.Module):
    def __init__(self, dim, num_heads, bias, mode):
        super(Attention, self).__init__()
        self.num_heads = num_heads
        self.temperature = nn.Parameter(torch.ones(num_heads, 1, 1))

        self.qkv_0 = nn.Conv2d(dim, dim, kernel_size=1, bias=bias)
        self.qkv_1 = nn.Conv2d(dim, dim, kernel_size=1, bias=bias)
        self.qkv_2 = nn.Conv2d(dim, dim, kernel_size=1, bias=bias)

        self.qkv1conv = nn.Conv2d(dim, dim, kernel_size=3, stride=1, padding=1, groups=dim, bias=bias)
        self.qkv2conv = nn.Conv2d(dim, dim, kernel_size=3, stride=1, padding=1, groups=dim, bias=bias)
        self.qkv3conv = nn.Conv2d(dim, dim, kernel_size=3, stride=1, padding=1, groups=dim, bias=bias)

        self.project_out = nn.Conv2d(dim, dim, kernel_size=1, bias=bias)

    def forward(self, x, mask=None):
        b, c, h, w = x.shape
        q = self.qkv1conv(self.qkv_0(x))
        k = self.qkv2conv(self.qkv_1(x))
        v = self.qkv3conv(self.qkv_2(x))
        if mask is not None:
            q = q * mask
            k = k * mask

        q = rearrange(q, 'b (head c) h w -> b head c (h w)', head=self.num_heads)
        k = rearrange(k, 'b (head c) h w -> b head c (h w)', head=self.num_heads)
        v = rearrange(v, 'b (head c) h w -> b head c (h w)', head=self.num_heads)

        q = torch.nn.functional.normalize(q, dim=-1)
        k = torch.nn.functional.normalize(k, dim=-1)
        attn = (q @ k.transpose(-2, -1)) * self.temperature
        attn = attn.softmax(dim=-1)
        out = (attn @ v)
        out = rearrange(out, 'b head c (h w) -> b (head c) h w', head=self.num_heads, h=h, w=w)
        out = self.project_out(out)
        return out

    def initialize(self):
        weight_init(self)


class MSA_head(nn.Module):
    def __init__(self, mode='dilation', dim=64, num_heads=8, ffn_expansion_factor=4, bias=False,
                 LayerNorm_type='WithBias'):
        super(MSA_head, self).__init__()
        self.norm1 = LayerNorm(dim, LayerNorm_type)
        self.attn = Attention(dim, num_heads, bias, mode)
        self.norm2 = LayerNorm(dim, LayerNorm_type)
        self.ffn = FeedForward(dim, ffn_expansion_factor, bias)

    def forward(self, x, mask=None):
        x = x + self.attn(self.norm1(x), mask)
        x = x + self.ffn(self.norm2(x))
        return x

    def initialize(self):
        weight_init(self)


class MSA_module(nn.Module):
    def __init__(self, dim=64):
        super(MSA_module, self).__init__()
        self.B_TA = MSA_head()
        self.F_TA = MSA_head()
        self.TA = MSA_head()
        self.Fuse = nn.Conv2d(2 * dim, dim, kernel_size=3, padding=1)
        self.Fuse2 = nn.Sequential(nn.Conv2d(dim, dim, kernel_size=1), nn.Conv2d(dim, dim, kernel_size=3, padding=1),
                                   nn.BatchNorm2d(dim), nn.ReLU(inplace=True))

    def forward(self, x, mask):
        N, C, H, W = x.shape
        mask = F.interpolate(mask, size=x.size()[2:], mode='bilinear')
        mask_d = mask.detach()
        mask_d = torch.sigmoid(mask_d)
        # print(mask_d.shape)
        # print(x.shape)
        xf = self.F_TA(x, mask_d)
        xb = self.B_TA(x, 1 - mask_d)
        # x = self.TA(x)
        x = torch.cat((xb, xf, x), 1)
        x = x.view(N, 3 * C, H, W)
        x = self.Fuse(x)
        # D = self.Fuse2(side_x + side_x * x)
        return x

    def initialize(self):
        weight_init(self)