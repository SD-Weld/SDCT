import cv2
import os

# 路径一定要是英文的

def extract_frames(video_path, frames_dir):
    # 如果目录不存在，则创建新目录
    if os.path.exists(video_path):
        if not os.path.exists(frames_dir):
            os.makedirs(frames_dir)
    # print(os.path.exists(frames_dir))

    # 读取视频文件
    cap = cv2.VideoCapture(video_path)
    print(cap)
    frame_count = 0

    # 循环遍历所有帧
    while True:
        ret, frame = cap.read()
        # print(frame)
        # 判断是否读取到了最后一帧
        if not ret:
            break

        # 根据帧号生成帧文件名
        frame_file = f"{frames_dir}/frame_{frame_count}.jpg"
        # print(frame_file)
        # 保存帧到指定目录
        cv2.imwrite(frame_file, frame)

        # 增加帧数计数器
        frame_count += 1
        # print(frame_count)
    # 释放视频资源
    cap.release()

    print(f"成功导出 {frame_count} 帧")


# 调用示例
# extract_frames('D:/0.管道焊缝缺陷检测/X射线数据集/avi/1-21.avi', 'D:/0/1-21')

# input=r"D:\0管道焊缝X射线检测\原始视频\第1轮avi\1-50x.avi"
# output=f"D:/0video/1/ax/1-50"
# extract_frames(input, output)

for i in range(25,34):
    # a=[10,49]
    # a=[10,49]
    for j in range(9,52):
    # for j in range(9,51):
        # print(i,j)
        ax=f"{i}-{j}"
        input=f"F:/4.30/{ax}x.avi"
        output=f"D:/0video\mask/{ax}x/"
        print(ax)
        extract_frames(input, output)