#!/usr/bin/python3
#coding=utf-8

import os
import sys
sys.path.insert(0, '../')
sys.dont_write_bytecode = True
os.environ["CUDA_VISIBLE_DEVICES"] = '0'

import cv2
import numpy as np
import matplotlib.pyplot as plt
plt.ion()

import torch
import argparse
import dataset
from torch.utils.data import DataLoader
from model.get_model import get_model
import datetime
import time

class Test(object):
    def __init__(self, Dataset, Path, model, checkpoint, task):
        ## task
        self.task = task 

        ## dataset
        self.cfg    = Dataset.Config(datapath=Path, snapshot=checkpoint, mode='test')
        self.data   = Dataset.Data(self.cfg, model)
        # self.loader = DataLoader(self.data, batch_size=1, shuffle=False, num_workers=8)

        ## network
        self.net = get_model(self.cfg, model)
        self.net.train(False)
        self.net.cuda()



    def save(self):
        with torch.no_grad():
            inf_time = 0
            start = datetime.datetime.now()
            start = time.time()
            # print(111)
            for image, (H, W), name in DataLoader(self.data, batch_size=1, shuffle=False, num_workers=0):
            # for image, (H, W), name in self.loader:
            #     print(1)
                image, shape  = image.cuda().float(), (H, W)
                # print(image.shape)
                # print(shape)
                # out1, out2, out3, out4 = self.net(image, shape, name)
                out1, out2, out3, out4, pose = self.net(image, shape, name)
                # print(3)
                pred = torch.sigmoid(out4[0,0]).cpu().numpy()*255
                # outputs_np = out.sigmoid().cpu().detach()
                # outputs  outputs_np
                # seg
                # pred[pred > 0.5]= 1
                # pred[pred < 1] = 0
                # print(4)
                if task == "SOC":
                    head = 'util/evaltool/Prediction/'+model+'/SOC/'+self.cfg.datapath.split('/')[-1]
                else:
                    head = 'Prediction/'+model+'/'+ self.cfg.datapath.split('/')[-2]
                if not os.path.exists(head):
                    print("create a new folder: {}".format(head))
                    os.makedirs(head)
                print(head)
                cv2.imwrite(head+'/'+name[0]+'.png', np.round(pred))
                # head.close()
            end = datetime.datetime.now()
            torch.cuda.synchronize()
            end = time.time()
            inf_time += (end - start)
            inf_per_image = inf_time / 500
            fps = 1 / inf_per_image
            print("inf_per_image1: {}, fps: {}".format(inf_per_image, fps))


if __name__=='__main__':

    parser = argparse.ArgumentParser()
    # ICON-V: VGG16, ICON-R: ResNet50, ICON-S: Swin384_22k, ICON-P: PVTv2, CycleMLP: B4
    parser.add_argument("--model", default='ICON-V')
    # Tasks: SOD, SOC-Attr, COD, FPS
    parser.add_argument("--task", default='V')
    parser.add_argument("--ckpt", default='../checkpoint/ICON/ICON-V/ICON-V110_BS8_X-ray')
    # parser.add_argument("--ckpt", default='checkpoint/ICON/ICON-P/ICON-PVT.weight')
    
    args   = parser.parse_args()
    task   = args.task
    model  = args.model
    ckpt   = args.ckpt
    
    print(args.model, args.ckpt)

    if args.task == "SOD":
        for path in ['../Test2']:
            t = Test(dataset, path, model, ckpt, task)
            t.save()

    elif args.task == "SOC":
        for path in ['datasets/SOC/SOC-AC', 'datasets/SOC/SOC-BO', 'datasets/SOC/SOC-CL', 'datasets/SOC/SOC-HO', 'datasets/SOC/SOC-MB', 'datasets/SOC/SOC-OC', 'datasets/SOC/SOC-OV', 'datasets/SOC/SOC-SC', 'datasets/SOC/SOC-SO']:
            t = Test(dataset, path, model, ckpt, task)
            t.save()

    elif args.task == "COD":
        for path in ['datasets/CHAMELEON/Test', 'datasets/CAMO/Test', 'datasets/COD10K/Test', 'datasets/CPD1K/Test']:
            t = Test(dataset, path, model, ckpt)
            t.save()

    else:
        # For testing FPS
        inf_time = 0
        for path in ['../dataset/X-ray-vieo/Test']:
            start = datetime.datetime.now()
            start = time.time()
            t = Test(dataset, path, model, ckpt,task)
            end = datetime.datetime.now()
            t.save()
            torch.cuda.synchronize()
            end = time.time()
            inf_time += (end - start)
        inf_per_image = inf_time / 500
        fps = 1 /  inf_per_image
        print("inf_per_image: {}, fps: {}".format(inf_per_image, fps))
